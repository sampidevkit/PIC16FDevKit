#ifndef INDICATOR_CFG_H
#define INDICATOR_CFG_H

#define NUM_OF_INDICATORS   2
#define IND_ACTIVELOGIC     1
#define IND_INACTIVELOGIC   0
#define LED1_SetState       PG_LED1_SetValue // System state
#define LED2_SetState       PG_LED2_SetValue // System state

#endif