#include "libcomp.h"
#include "AppMain.h"

public void APP_Main_Initialize(void) // <editor-fold defaultstate="collapsed" desc="Application Initialize">
{
    PG_LED2_SetHigh();
} // </editor-fold>

public void APP_Main_Tasks(void) // <editor-fold defaultstate="collapsed" desc="Application Main Task">
{

} // </editor-fold>