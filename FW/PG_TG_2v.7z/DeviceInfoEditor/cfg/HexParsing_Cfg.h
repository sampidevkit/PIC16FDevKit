#ifndef HEXPARSING_CFG_H
#define HEXPARSING_CFG_H

#define HEXPARSE_StreamOut(x)
#define HEXPARSE_StreamOut(x)
#define HEXPARSE_NVM_Write(Addr, pData, Len) DATA_Write(Addr, pData, Len)

#endif