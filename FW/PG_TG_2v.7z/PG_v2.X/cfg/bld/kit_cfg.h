#ifndef KIT_CFG_H
#define KIT_CFG_H

#define KIT_STARTUP_DELAY 2 // second

#endif