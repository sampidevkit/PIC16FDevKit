#ifndef KIT_USB_CFG_H
#define KIT_USB_CFG_H
// Nothing

#endif