This Driver package is an unsigned template .inf file. It is for 
development and submittal for WHQL certification. It has been generated 
by MCC to already have your selection of VID PID and some strings. To 
complete the modification necessary to obtain WHQL certification consult
the document "USB - Obtaining a WHQL Certified USB Driver Package.pdf" 
also included as a part of this utilities folder.