#include "libcomp.h"
#include "AppMain.h"

public void APP_Main_Initialize(void) // <editor-fold defaultstate="collapsed" desc="Application Initialize">
{
    RLED_EXT_SetHigh();
    GLED_EXT_SetHigh();
} // </editor-fold>

public void APP_Main_Tasks(void) // <editor-fold defaultstate="collapsed" desc="Application Main Task">
{

} // </editor-fold>