#include "libcomp.h"

int main(void)
{
    SYSTEM_Initialize();
    KIT_Tasks();

    return 1;
}